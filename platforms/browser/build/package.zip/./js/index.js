
if (typeof(Storage) === "undefined") {
    console.log("Sorry! No Web Storage support...");
} else {
	if (typeof(localStorage.userName) === "undefined") {
		localStorage.userName = "LEANDRO";
	}
}

function shuffleArray(array) {
    for (var i = array.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        /*var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);*/
        
    }
};


function navBar(){
	var nav = "<ul class=\"nav navbar-nav\"><li class=\"active\"><a href=\"m0.html\">INÏCIO</a></li></ul><ul class=\"nav navbar-nav navbar-right\"><li><a href=\"index.html\">SAIR</a></li></ul>";
	$("#bs-example-navbar-collapse-1").append(nav);
}
